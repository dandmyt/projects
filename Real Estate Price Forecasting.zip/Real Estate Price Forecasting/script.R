
# WCZYTYWANIE DANYCH
dane <- read.csv("apartments_pl_2024_06.csv", sep = ",", dec = ".")

# BIBILIOTEKI
library(VIM) # k-najbliższych sąsiadów
library(ggplot2) # wykresy
library(dplyr)  # manipulacja danymi filter, select itd 
library(patchwork) # biblioteka do łączenia wykresów
library(scales) # łatwe formatowanie etykiet na osiach wykresów.(wspomaga ggplot2)
library(caret) #  podzial danych na zbiory testowe i treningowe  (Classification And REgression Training) 

# Analiza wstępna:

#FILTROWANIE i wybor ZMIENYCH wg MIASTA
dane_projekt <- dane %>%
  filter(tolower(city) == "warszawa") %>%
  select(price, squareMeters, rooms, centreDistance, buildYear, floor, hasParkingSpace)


#sprawdzenie brakow danych
colSums(is.na(dane_projekt))


# implementacja zmiennych Floor oraz buildYear za pomoca metody KNN

dane_imp <- kNN(dane_projekt, 
                variable = c("buildYear", "floor"), 
                k = 5, 
                imp_var = FALSE) # imp_var = FALSE nie tworzy dodatkowych kolumn logicznych

# # Usuwamy 2% najdroższych mieszkań, które najbardziej zaburzają błąd modelu (RMSE)
# prog_cenowy <- quantile(dane_imp$price, 0.98)
# dane_imp <- dane_imp %>% filter(price < prog_cenowy)
# 



# Rozklady zmiennych

# Ujednolicona wielkość czcionki 
font_size <- 12

# --- 1. ROK BUDOWY (Niebieski) ---
p1 <- ggplot(dane_imp, aes(x = buildYear)) +
  geom_bar(fill = "#2980b9", color = "white") +
  labs(title = "Rozkład mieszkań wg roku budowy",
       subtitle = "Struktura wiekowa ofert w Warszawie",
       x = "Rok budowy", y = "Liczba ofert") +
  theme_minimal(base_size = font_size)

# --- 2. PIĘTRO (Zielony) ---
p2 <- ggplot(dane_imp, aes(x = as.factor(floor))) +
  geom_bar(fill = "#27ae60", color = "white") +
  labs(title = "Rozkład ofert wg piętra",
       subtitle = "Liczba dostępnych lokali na kondygnacjach",
       x = "Piętro", y = "Liczba ofert") +
  theme_minimal(base_size = font_size) +
  theme(panel.grid.major.x = element_blank())

# --- 3. METRAŻ (Czerwony/Bordo) ---
p3 <- ggplot(dane_imp, aes(x = squareMeters)) +
  geom_histogram(fill = "#c0392b", color = "white", bins = 30) +
  labs(title = "Rozkład metrażu mieszkań",
       subtitle = "Wielkość lokali w m2",
       x = "Metraż (m2)", y = "Liczba ofert") +
  theme_minimal(base_size = font_size)

# --- 4. ODLEGŁOŚĆ OD CENTRUM (Pomarańczowy) ---
p4 <- ggplot(dane_imp, aes(x = centreDistance)) +
  geom_histogram(fill = "#e67e22", color = "white", bins = 30) +
  labs(title = "Odległość mieszkań od centrum",
       subtitle = "Lokalizacja ofert względem Śródmieścia",
       x = "Dystans (km)", y = "Liczba ofert") +
  theme_minimal(base_size = font_size)

# --- 5. LICZBA POKOI (Fioletowy) ---
p5 <- ggplot(dane_imp, aes(x = as.factor(rooms))) +
  geom_bar(fill = "#8e44ad", color = "white") +
  labs(title = "Rozkład liczby pokoi",
       subtitle = "Podział ofert wg liczby pomieszczeń",
       x = "Liczba pokoi", y = "Liczba ofert") +
  theme_minimal(base_size = font_size) +
  theme(panel.grid.major.x = element_blank())

# --- 6. CENA (Ciemny Granat) ---
p6 <- ggplot(dane_imp, aes(x = price)) +
  geom_histogram(fill = "#2c3e50", color = "white", bins = 40) +
  scale_x_continuous(labels = label_number(suffix = " zł", big.mark = " ")) +
  scale_y_continuous(labels = label_number(big.mark = " ")) +
  labs(title = "Rozkład cen nieruchomości",
       subtitle = "Wartość rynkowa mieszkań w Warszawie",
       x = "Cena (PLN)", y = "Liczba ofert") +
  theme_minimal(base_size = font_size)

# Łączenie wykresów w jeden obraz (wymaga library(patchwork))
(p1 + p2 + p3) / (p4 + p5 + p6)


# Konwersja na factor (zmienna kategoryczna)
dane_imp$hasParkingSpace <- as.factor(dane_imp$hasParkingSpace)

# Sprawdzenie struktury
str(dane_imp$hasParkingSpace)


# Skalujemy tylko zmienne numeryczne (bez ceny i bez parkingu)
dane_skalowane <- dane_imp
dane_skalowane[c("squareMeters", "rooms", "centreDistance", "buildYear", "floor")] <- scale(dane_imp[c("squareMeters", "rooms", "centreDistance", "buildYear", "floor")])

# Logarytmowanie ceny - to kluczowy krok dla zmniejszenia błędu procentowego
dane_skalowane$price_log <- log(dane_skalowane$price)


#PODZIAŁ DANYCH
set.seed(123) 

# Tworzymy listę indeksów dla 80% danych
index <- createDataPartition(dane_skalowane$price, p = 0.8, list = FALSE)

# Tworzymy dwa osobne zbiory
train_set <- dane_skalowane[index, ] # Na tym model się uczy
test_set <- dane_skalowane[-index, ] # Na tym sprawdzimy model na samym końcu

# KONFIGURACJA KROSWALIDACJI (Sprawdziany cząstkowe)
# Ustawiamy 10-krotną kroswalidację (Cross-Validation)
train_control <- trainControl(method = "cv", number = 10)


#BUDOWA MODELU (Nauka)

# price ~ . oznacza: "przewiduj cenę na podstawie wszystkich innych kolumn"
model_finalny <- train(
  price_log ~ squareMeters + rooms + centreDistance + buildYear, 
  data = train_set, 
  method = "lm", 
  trControl = train_control
)
# 1. Zobaczmy, które zmienne działają (Szukamy gwiazdek ***)
summary(model_finalny$finalModel)



# 2. Prognozowanie (wynik będzie w skali log)
prognozy_log <- predict(model_finalny, newdata = test_set)

# 3. POWRÓT DO ZŁOTÓWEK (to jest klucz!)
prognozy_pln <- exp(prognozy_log)

# 4. Sprawdzenie jakości na prawdziwych cenach
jakosc_log <- postResample(pred = prognozy_pln, obs = test_set$price)
print(jakosc_log)




















